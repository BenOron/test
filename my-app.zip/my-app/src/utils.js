import axios from 'axios';

export const getData= async(filePath)=>{
  fetch(filePath)
  .then(res=>res.clone().json())
  .catch(function(error) {
    console.log(error);
  });
  }
