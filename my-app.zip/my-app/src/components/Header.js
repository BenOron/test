import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';


const Header = (props) => {
    const {HeaderTitle} = props;
    return (
        <AppBar position="static">
        <Toolbar variant="dense">            
            <Typography variant="h6" color="inherit" component="div">
                Data Report
            </Typography>
        </Toolbar>
        </AppBar>
    )

}


export default Header;