import React,{useState,useEffect,useCallback} from 'react';
import { DataGrid, GridFilterModel } from '@mui/x-data-grid';
import Box from '@mui/material/Box';
import mockCompanies from '../mockData/API/companies.json'
import mockCountries from '../mockData/API/performance/countries.json'


const Table = () =>  {
  //const { columns, setColumns } = useState([]);
  const [queryOptions, setQueryOptions] = useState({});
  const [dataMockCompanies,setDataMockCompanies] = useState(mockCompanies); 
  const [dataMockCountries,setMockCountries] = useState(mockCountries); 
  const [columns,setColumns] = useState([]); 
  const [data,setData] = useState()

  const onFilterChange = useCallback((filterModel: GridFilterModel) => {
    // Here you save the data you need from the filter model
    setQueryOptions({ filterModel: { ...filterModel } });
  }, []);



  const columnsItems =  [        
        {
          "field": "display_name",
          "headerName": "Company",
          "width": 300
        },
        {
          "field": "country",        
          "headerName": "Country",
          "width": 180,
          "editable": false
        },
        {
          "field": "installs",
          "headerName": "Installs",
          "width": 120,
          "editable": false
        },
        {
          "field": "roi",
          "headerName": "ROI",
          "width": 150,
          "editable": false
        },
        {
          "field": "industry_roi",
          "headerName": "Industry ROI",
          "type": "number",
          "width": 140,
          "editable": false
        }
      ];

  


  useEffect(()=> {  
    setColumns(columnsItems);    
  },[])



  return (
    <Box sx={{ height: 520, width: '100%' }}>
      <DataGrid    
        rowLength={100}
        editable={true} 
        rows={dataMockCountries}
        getRowId={(row: any) =>  row.id + row.iso}
        columns={columns}
        filterMode="server"
        onFilterModelChange={onFilterChange}
        //loading={isLoading}
      />
    </Box>
  );
}

export default Table