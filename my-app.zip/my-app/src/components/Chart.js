import React,{useEffect} from 'react';
import Paper from '@mui/material/Paper';
import {
  Chart,
  ArgumentAxis,
  ValueAxis,
  BarSeries,
} from '@devexpress/dx-react-chart-material-ui';
import company_1 from '../mockData/API/performance/countries/company_1.json'//as mocks
import { scaleBand } from '@devexpress/dx-chart-core';
import { ArgumentScale, Stack } from '@devexpress/dx-react-chart';

const ChartView = (props) => {  
  //onst {data} = props;
  const data =  { data: company_1 }  
  
  useEffect(()=>{
    console.log(data);
  })

    return (
        <Paper>
          {/* <Chart
            data={data}
          >
            <ArgumentScale factory={scaleBand} />
            <ArgumentAxis />
            <ValueAxis />
            <BarSeries
              // valueField="cost"
              // argumentField="installs"
              // name="revenue"
            />                       
            <Stack />
          </Chart> */}
        </Paper>
      );
}   


export default ChartView;