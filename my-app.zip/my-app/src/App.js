import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Tabs from './components/Tabs';
import Table from './components/Table';

function App() {
  return (
    <div className="App">
      <Header/>   
     <div style={{padding:'4vw'}}> 
      <Tabs />   
      <Table/>
      </div>
    </div>
  );
}

export default App;
